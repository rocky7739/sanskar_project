#!/bin/bash

nohup php server.php > nohup.log &
