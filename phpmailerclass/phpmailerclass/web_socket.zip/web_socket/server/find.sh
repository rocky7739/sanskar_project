#!/bin/bash

ps auxwww|grep -i 'server.php'